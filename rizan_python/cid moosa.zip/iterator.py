# mytuple = ("apple", "banana", "cherry")
# tuple1=iter(mytuple)

# print(next(tuple1))
# print(next(tuple1))
# print(next(tuple1))

# mystr = "banana"
# myit = iter(mystr)

# print(next(myit))
# print(next(myit))
# print(next(myit))
# print(next(myit))
# print(next(myit))
# print(next(myit))